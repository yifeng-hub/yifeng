/**
 ****************************************************************************************
 *
 * @file user_custs1_def.h
 *
 * @brief Custom Server 1 (CUSTS1) profile database definitions.
 *
 * Copyright (C) 2016-2019 Dialog Semiconductor.
 * This computer program includes Confidential, Proprietary Information
 * of Dialog Semiconductor. All Rights Reserved.
 *
 ****************************************************************************************
 */

#ifndef _USER_CUSTS1_DEF_H_
#define _USER_CUSTS1_DEF_H_

/**
 ****************************************************************************************
 * @defgroup USER_CONFIG
 * @ingroup USER
 * @brief Custom Server 1 (CUSTS1) profile database definitions.
 *
 * @{
 ****************************************************************************************
 */

/*
 * INCLUDE FILES
 ****************************************************************************************
 */

#include "attm_db_128.h"

/*
 * DEFINES
 ****************************************************************************************
 */

// Service 1 of the custom server 1
#define DEF_SVC1_UUID_128                {0x59, 0x5a, 0x08, 0xe4, 0x86, 0x2a, 0x9e, 0x8f, 0xe9, 0x11, 0xbc, 0x7c, 0x9E, 0x43, 0x42, 0x18}

// Add more channels
#define DEF_SVC1_LONG_VALUE_SW_UUID_128     {0x8C, 0x09, 0xE0, 0xD1, 0x81, 0x54, 0x42, 0x40, 0x8E, 0x4F, 0xD2, 0xB3, 0x78, 0xE3, 0x2A, 0x77}
#define DEF_SVC1_LONG_VALUE_MODE_UUID_128     {0x8C, 0x09, 0xE0, 0xD1, 0x81, 0x54, 0x42, 0x40, 0x8E, 0x4F, 0xD2, 0xB3, 0x79, 0xE3, 0x2A, 0x77}
#define DEF_SVC1_LONG_VALUE_FREQ_UUID_128     {0x8C, 0x09, 0xE0, 0xD1, 0x81, 0x54, 0x42, 0x40, 0x8E, 0x4F, 0xD2, 0xB3, 0x7A, 0xE3, 0x2A, 0x77}
#define DEF_SVC1_LONG_VALUE_P_AMP_UUID_128     {0x8C, 0x09, 0xE0, 0xD1, 0x81, 0x54, 0x42, 0x40, 0x8E, 0x4F, 0xD2, 0xB3, 0x7B, 0xE3, 0x2A, 0x77}
#define DEF_SVC1_LONG_VALUE_P_RATIO_UUID_128     {0x8C, 0x09, 0xE0, 0xD1, 0x81, 0x54, 0x42, 0x40, 0x8E, 0x4F, 0xD2, 0xB3, 0x7D, 0xE3, 0x2A, 0x77}
#define DEF_SVC1_LONG_VALUE_N_RATIO_UUID_128     {0x8C, 0x09, 0xE0, 0xD1, 0x81, 0x54, 0x42, 0x40, 0x8E, 0x4F, 0xD2, 0xB3, 0x7E, 0xE3, 0x2A, 0x77}
#define DEF_SVC1_LONG_VALUE_PN_INTERVAL_RATIO_UUID_128     {0x8C, 0x09, 0xE0, 0xD1, 0x81, 0x54, 0x42, 0x40, 0x8E, 0x4F, 0xD2, 0xB3, 0x7F, 0xE3, 0x2A, 0x77}

// Add more channels
#define DEF_SVC1_LONG_VALUE_SW_CHAR_LEN    20
#define DEF_SVC1_LONG_VALUE_MODE_CHAR_LEN    20
#define DEF_SVC1_LONG_VALUE_FREQ_CHAR_LEN    20
#define DEF_SVC1_LONG_VALUE_P_AMP_CHAR_LEN    2
#define DEF_SVC1_LONG_VALUE_P_RATIO_CHAR_LEN    20
#define DEF_SVC1_LONG_VALUE_N_RATIO_CHAR_LEN    20
#define DEF_SVC1_LONG_VALUE_PN_INTERVAL_RATIO_CHAR_LEN    20

// Add more channels
#define DEF_SVC1_LONG_VALUE_SW_CHAR_USER_DESC    "Stimulation Switch"
#define DEF_SVC1_LONG_VALUE_MODE_CHAR_USER_DESC    "Stimulation Mode"
#define DEF_SVC1_LONG_VALUE_FREQ_CHAR_USER_DESC    "Stimulation Freq"
#define DEF_SVC1_LONG_VALUE_P_AMP_CHAR_USER_DESC    "Battery Sample"
#define DEF_SVC1_LONG_VALUE_P_RATIO_CHAR_USER_DESC    "Stimulation P Ratio"
#define DEF_SVC1_LONG_VALUE_N_RATIO_CHAR_USER_DESC    "Stimulation N Ratio"
#define DEF_SVC1_LONG_VALUE_PN_INTERVAL_RATIO_CHAR_USER_DESC    "Stimulation PN Interval Ratio"

/// Custom1 Service Data Base Characteristic enum
enum
{
    // Custom Service 1
    SVC1_IDX_SVC = 0,

		// Add more channels
		SVC1_IDX_LONG_VALUE_SW_CHAR,
    SVC1_IDX_LONG_VALUE_SW_VAL,
    SVC1_IDX_LONG_VALUE_SW_NTF_CFG,
    SVC1_IDX_LONG_VALUE_SW_USER_DESC,
		
		SVC1_IDX_LONG_VALUE_MODE_CHAR,
    SVC1_IDX_LONG_VALUE_MODE_VAL,
    SVC1_IDX_LONG_VALUE_MODE_NTF_CFG,
    SVC1_IDX_LONG_VALUE_MODE_USER_DESC,
		
		SVC1_IDX_LONG_VALUE_FREQ_CHAR,
    SVC1_IDX_LONG_VALUE_FREQ_VAL,
    SVC1_IDX_LONG_VALUE_FREQ_NTF_CFG,
    SVC1_IDX_LONG_VALUE_FREQ_USER_DESC,
    
		SVC1_IDX_LONG_VALUE_P_AMP_CHAR,
    SVC1_IDX_LONG_VALUE_P_AMP_VAL,
    SVC1_IDX_LONG_VALUE_P_AMP_NTF_CFG,
    SVC1_IDX_LONG_VALUE_P_AMP_USER_DESC,
	
		SVC1_IDX_LONG_VALUE_P_RATIO_CHAR,
    SVC1_IDX_LONG_VALUE_P_RATIO_VAL,
    SVC1_IDX_LONG_VALUE_P_RATIO_NTF_CFG,
    SVC1_IDX_LONG_VALUE_P_RATIO_USER_DESC,
		
		SVC1_IDX_LONG_VALUE_N_RATIO_CHAR,
    SVC1_IDX_LONG_VALUE_N_RATIO_VAL,
    SVC1_IDX_LONG_VALUE_N_RATIO_NTF_CFG,
    SVC1_IDX_LONG_VALUE_N_RATIO_USER_DESC,
		
		SVC1_IDX_LONG_VALUE_PN_INTERVAL_RATIO_CHAR,
    SVC1_IDX_LONG_VALUE_PN_INTERVAL_RATIO_VAL,
    SVC1_IDX_LONG_VALUE_PN_INTERVAL_RATIO_NTF_CFG,
    SVC1_IDX_LONG_VALUE_PN_INTERVAL_RATIO_USER_DESC,
		
    CUSTS1_IDX_NB
};

/// @} USER_CONFIG

#endif // _USER_CUSTS1_DEF_H_
